

// ملف الهيدر بتاع التغليف الي استعملناه لمكتبه القاعده /
#include "sqlite_modern_cpp.h"
// بص انته مش هتحتاج تستدعي غير الملف ده بس لان جوه ملفات التليف دي هو مستدعي لوحده مكاتب تانيه كتير هتترجم تلقائي من ضمنها حتي مكتبه iostream , sqlite3 ,string 
using namespace sqlite;
// ده namespace بتاع التغليف الي استعملناه اكتبه ومتشغلش بالك بيه 
using namespace std;

int main() {
    try {
        // الاكواد بتاعتنا هنا مكتوب جوه هنا عشان يهندل الاخطاء استعمل نفس الطريقه وخلاص 
        database db("dbfile.db");
        // الاتصال بقاعده البيانات dbfile.db
// دول شويه اوامر عشان يعملوا قاعده البيانات عشان لو مش موجوده ويهياءوها لكنها بالفعل جاهزه فطنشهم        
db << "CREATE TABLE IF NOT EXISTS books ("
   "id INTEGER PRIMARY KEY AUTOINCREMENT, "
   "name TEXT NOT NULL UNIQUE, "
   "author TEXT NOT NULL, "
   "price INTEGER NOT NULL, "
   "quantity INTEGER NOT NULL);";

        // //دي بقي اهم حاجه دي شكل الامر الي هتستخدمه عشان تضيف اي قيم جديده جوه قاعده البيانات تمام
        // db << "INSERT INTO books (name, author, price, quantity) VALUES (?,?,?,?);" << "C++ Programming" << "Bjarne Stroustrup" << 50 << 10;
        // // اهم جزئ الي تركز فيه وتكرف للباقي هو اول حاجه اسم الجدول الي هتضيف فيه الي هو book هنا واسماء الصفوف الي هتضيف فيها البيانات
        // db << "INSERT INTO books (name, author, price, quantity) VALUES (?,?,?,?);" << "Effective Modern C++" << "Scott Meyers" << 40 << 5;
        // // فيه خصائص لكل عمود وهما الموجودين في الاوامر الي بتهئ قاعده البيانات زي مثلا ان name,author price ,quantity مينفعش يبقوا فاضيين فتلقائي لو دخلت واحده بس مدخلتش الاربعه سوا هيجبلك خطا خد بالك
        // cout << "Books inserted successfully!" << endl;
        // // استرجاع البيانات وطباعتها
        // cout << "Books in the database:" << endl;
        // db << "SELECT name, author, price, quantity FROM books;" >> [&] (string name, string author, int price, int quantity) {
        //     cout << "Name: " << name << ", Author: " << author << ", Price: " << price << ", Quantity: " << quantity << endl;
        // };
    //    الاكواد الي فوق دي هي الطريقه الي بنجيب بيها البيانات من قاعده البيانات لكن هنا بيعرض كل البيانات الموجوده في القاعده او بالاصح الموجوده في الصف الي اختارناه فوق الي خو name,author,price,quantity
        // جدول المستخدمين
// db << "CREATE TABLE IF NOT EXISTS users ("
//    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
//    "name TEXT NOT NULL, "
//    "password TEXT NOT NULL, "
//    "permission INTEGER NOT NULL DEFAULT 0);";
// نفس الكلام تهيئه قاعده البيانات لكن لجدول المستخدمين 

//         // إدخال بعض البيانات
//         db << "INSERT INTO users (name , password) VALUES (?,?);" << "Alice" << "password123";
//         db << "INSERT INTO users (name, password) VALUES (?,?);" << "Bob" << "securepass";
//         db << "INSERT INTO users (name, password) VALUES (?,?);" << "ahmed"<< "ahmed2024";

//         cout << "Records inserted successfully!" << endl;

//         // استرجاع البيانات وطباعتها
//         cout << "Users in the database:" << endl;
//         db << "SELECT name , password FROM users;" >> [&] (string name, string password) {
//             cout << "Name: " << name << " password: "<<password <<endl;
//         };
//         // الصلاحيات مثلا
//                 cout << "permission in the database:" << endl;
//         db << "SELECT permission FROM users;" >> [&] (string name) {
//             cout << "permission: " << name << endl;
//         };
// شكلين لاسترجاع البيانات اهم عشان ميبقاش ليك حجه 


// =============
// هتحتاج كمان حاجه ونته شغال وهي ازاي تستعلم عن قيمه معينه مثلا حد بيسجل ازاي اتاكد انه موجود كلتالي
    string username, password;
    cout << "Username: ";
    cin >> username;
    cout << "Password: ";
    cin >> password;

    // متغير لتخزين نتيجة الاستعلام
    bool authenticated = false;

    // الاستعلام: هل يوجد مستخدم بهذا الاسم وكلمة المرور؟
    db << "SELECT 1 FROM users WHERE name = ? AND password = ?;"<< username << password >> [&](int) {  // لا نحتاج القيمة، فقط وجود الصف كافٍ
            authenticated = true;
          };
        // بص دي شبه جمله شرطيه لو شرط ان الاسم والباسورد موجودين في نفس الصف هينفذ الكود الي جوه انه يخلي قيمه المتغير الي بنشرط بيه تحت بي واحد غير كده مش هيتنفذ

    if (authenticated) {
        cout << " Login successful!" << endl;
    } else {
        cout << " Invalid username or password." << endl;
    }

// =============
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }
    // دي داله بتعرضلك الخطا الي بيحصل جوه قاعده البيانات لو حصل فكك منها 
    // المهم انها اول ما بيحصل خظا بتوقف الكود خالص وتطبع الخطا ودي الاجابه بتاعت الtry الي فوق

    return 0;
}